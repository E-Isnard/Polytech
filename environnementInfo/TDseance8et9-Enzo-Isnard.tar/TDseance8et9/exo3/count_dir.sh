#!/bin/bash
ls -la | grep -c "^d"
