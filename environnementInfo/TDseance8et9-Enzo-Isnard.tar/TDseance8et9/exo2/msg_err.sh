#!/bin/bash
echo Message normal
echo Message anormal 1>&2
