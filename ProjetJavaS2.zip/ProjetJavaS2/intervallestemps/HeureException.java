package intervallestemps;

/**
 * DateException
 */
public class HeureException extends Exception {


    private static final long serialVersionUID = -1159155666976674640L;

    public HeureException() {
        super();
    }

    public String toString() {
        return "Erreur: heure incorrecte";
    }
    
}