package intervallestemps;

public class Duree extends Heure {

    public Duree(Double d) throws HeureException{
        super(d);
    }

}