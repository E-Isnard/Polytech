for N in un deux trois quatre
do
echo "**$N**"
done


