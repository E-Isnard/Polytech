for N in $(ls)
do
echo "Fichier -> $N"
done
