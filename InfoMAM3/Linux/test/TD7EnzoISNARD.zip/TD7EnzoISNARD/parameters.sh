echo "nombre de paramètres : \$# = $#"
echo "liste des paramètres : \$* = $*"
